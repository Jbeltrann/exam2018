"""
What is the most interesting/funny/cool thing(s) about Python that you learned from this class or from somewhere else.

You can use code or a short paragraph to illustrate it.
"""
"Hands down, assignment 2 was one of the more satisfying projects. I was able to do a text analysis on something I was very interested in and I learned how to do it from scratch. 
"The class as a whole has also helped me compartmentalize parts of a solution to a problem and develop my logic and problem solving skills further. 
"Even if I don't end up using python to its full extent, I can now say that I can at least make sense of code if it was placed in front of me (if it is things covered by the class , that is."

