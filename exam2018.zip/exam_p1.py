def get_value(name):
    letter_dict = {'a': 1, 'b':2, 'c':3,'d':4,'e':5,'f':6,'g':7,'h':8,
    'i':9,'j':10,'k':11,'l':12,'m':13,'n':14,'o':15,'p':16,'q':17,
    'r':18,'s':19,'t':20,'u':21,'v':22,'w':23,'x':24,'y':25,'z':26
    }
    nameval = sum([ord(letter.lower())-96 for letter in letter_dict])
      
    return nameval


def  get_name_list(file_name):
    roster = open(file_name).read().splitlines()
    first_name = [roster.split(' ')[0] for full_name in roster]
    name_list = [name.lower() for name in first_name]
        
    return name_list
    

def name_highest_value(name_list):
    i = 0
    highest_name = name_list[0]
    highest_name_value = get_value(name_list[0])
    name = name_list[i]
    for name in name_list:
        name_value = get_value(name)
        if name_value > highest_name_value:
            highest_name_value = name_value
            highest_name = name
        i += 1
    print(highest_name, highest_name_value)
    

def roster_name_values(name_list):
    i = 0
    roster_dict = {}
    name = name_list[i]
    for name in name_list:
        roster_dict[name] = get_value(name)
    i += 1
    return roster_dict

def get_words(file_name):
    from_word_list = open(file_name).read().splitlines()
    word_list = [word.lower() for word in from_word_list]
    return word_list

def word_values(word_list):
    worddictionary = {}
    words = 0
    name = word_list[words]
    for word in word_list:
        worddictionary[word] = get_value(name)
    words += 1
    return worddictionary

def word_with_same_value (worddictionary, myname):
    val = get_value("Jonathan")
    word_list = open("exam2017/exam2018-master/positive-words.txt")
    ls =[]
    for word in word_list:
        if get_value(word) == val:
            ls.append(word[0])
    if ls == []:
        return None
    return ls


def main():
    roster = open("exam2017/exam2018-master/roster.txt")

    print(get_value('jonathan'))

    # roster_dict = roster_name_values(name_list)

    word_list = get_words('Exam2017/exam2018-master/positive-words.txt')

    word_dict = word_values(word_list)

    print(word_with_same_value(word_dict, get_value('jonathan')))

if __name__ == '__main__':
    main()

# print(get_name_list("exam2017/exam2018-master/roster.txt"))